var admin = require("firebase-admin");

var serviceAccount = require("/Users/beats/node/server/firealram-28fc0-firebase-adminsdk-h3vgz-d9730f9111.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://firealram-28fc0.firebaseio.com"
});
// var payload = {
//     notification:
//     {
//         title : "FIRE!!",
//         body : "대피하세요!!"
//     }
// };

const options = {
    priority: "high",     //메시지 중요도 설정 
    timeToLive: 60 * 60 * 2 ////메시지 Live Time 설정
}; 

var message = {
    // notification:
    // {
    //     title : "FIRE!!",
    //     body : "대피하세요!!"
    // },
    data: {  
        message : JSON.stringify(
            //type:'10',
            //channel: '10',
            '불이 났습니다. 대피하세요!!!!'
           // content: '****호에서 불이남'
        )
    }
    
};


admin.messaging().sendToTopic('Test', message, options).then(function(response) {
    console.log("Successfully sent message:", response);
})
.catch(function(error) {
    console.log("Error sending message:", error);
});